#' @keywords internal
#' @import rlang
#' @importFrom dplyr across
#' @importFrom glue glue glue_data
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL

utils::globalVariables(c("."))
