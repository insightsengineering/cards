# modify_footnote_spanning_header() messaging

    Code
      modify_footnote_spanning_header(base_tbl_summary, footnote = "Treatment as of June",
        columns = all_stat_cols(), level = 0L)
    Condition
      Error in `modify_footnote_spanning_header()`:
      ! The `level` argument must be a positive integer.

---

    Code
      remove_footnote_spanning_header(base_tbl_summary, columns = all_stat_cols(),
      level = 0L)
    Condition
      Error in `remove_footnote_spanning_header()`:
      ! The `level` argument must be a positive integer.

