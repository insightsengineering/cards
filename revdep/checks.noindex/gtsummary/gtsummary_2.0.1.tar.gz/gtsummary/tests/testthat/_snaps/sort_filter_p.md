# sort_p() messaging

    Code
      sort_p(tbl_summary(trial, by = trt, include = c(response, marker, trt),
      missing = "no"))
    Condition
      Error in `sort_p()`:
      ! There is no column named "p.value" in `x$table_body`.

# filter_p() messaging

    Code
      filter_p(tbl_summary(trial, by = trt, include = c(response, marker, trt),
      missing = "no"))
    Condition
      Error in `filter_p()`:
      ! There is no column named "p.value" in `x$table_body`.

