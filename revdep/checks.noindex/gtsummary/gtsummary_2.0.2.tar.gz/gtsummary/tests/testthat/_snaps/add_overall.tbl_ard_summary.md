# add_overall.tbl_summary() errors

    Code
      add_overall(tbl_ard_summary(ard_overall), cards = ard_overall)
    Condition
      Error:
      ! object 'ard_overall' not found

