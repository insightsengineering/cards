library(testthat)
test_check("cardx", stop_on_warning = TRUE)
