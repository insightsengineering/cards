# ard_stats_poisson_test() errors are handled correctly

    Code
      ard_stats_poisson_test(cards::ADTTE, by = TRTA, variables = c(CNSR, AVAL))
    Condition
      Error in `ard_stats_poisson_test()`:
      ! The `by` argument must have a maximum of two levels.

