#' @keywords internal
#' @import rlang
#' @importFrom dplyr across
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL

utils::globalVariables(c("."))
